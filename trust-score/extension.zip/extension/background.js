// ============================================
// TRUST KARO — BACKGROUND SERVICE WORKER
// Orchestrates scraping in foreground tabs
// ============================================

const API_BASE = "http://127.0.0.1:8010";

// ── Detect platform from URL ────────────────────────────────
function detectPlatform(url) {
  if (/amazon\.(in|com)/i.test(url)) return "amazon";
  if (/flipkart\.com/i.test(url)) return "flipkart";
  if (/myntra\.com/i.test(url)) return "myntra";
  return null;
}

// ── Listen for messages from popup.js or website_bridge ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // ---------- START SCRAPE (from popup or website bridge) ----------
  if (msg.action === "startScrape") {
    const { url, platform, fromWebsite, isHomePage } = msg;
    // Use sender.tab.id when message comes from a content script (website bridge)
    const originTabId = msg.originTabId || (sender.tab ? sender.tab.id : null);

    console.log(`[TrustKaro] Starting ${platform} scrape for: ${url}`);
    console.log(`[TrustKaro] Origin tab: ${originTabId}`);

    // ── SIMULTANEOUSLY kick off price comparison BEFORE opening scrape tab ──
    // This gives price scraping a ~30–90 s head start so results may already
    // be ready by the time the user sees the results dashboard.
    let priceSessionId = null;
    fetch(`${API_BASE}/api/price/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    })
    .then(r => r.json())
    .then(d => {
      if (d.status === 'success') {
        priceSessionId = d.session_id;
        console.log('[TrustKaro-Price] Simultaneous price session started:', priceSessionId);
        priceOrchestrateAll(url, priceSessionId);
      }
    })
    .catch(err => console.warn('[TrustKaro-Price] Could not start price session:', err));

    // Open the product page as the ACTIVE tab so the user can see progress
    // and Chrome does NOT throttle it (fixes "dead window" issue)
    chrome.tabs.create({ url, active: true }, (scrapeTab) => {

      let scrapeTabId = scrapeTab.id;

      // ── Inject overlay + scraper on every page load ───────────
      function injectScraper(tabId) {
        console.log(`[TrustKaro] Injecting overlay + ${platform} scraper into tab ${tabId}…`);

        // Inject overlay first, then the platform scraper
        chrome.scripting.executeScript({
          target: { tabId },
          files: ["scrapers/overlay.js"]
        }, () => {
          if (chrome.runtime.lastError) {
            console.error("[TrustKaro] Overlay injection error:", chrome.runtime.lastError.message);
          }
          chrome.scripting.executeScript({
            target: { tabId },
            files: [`scrapers/${platform}.js`]
          }, () => {
            if (chrome.runtime.lastError) {
              console.error("[TrustKaro] Scraper injection error:", chrome.runtime.lastError.message);
            } else {
              console.log(`[TrustKaro] Scraper injected successfully`);
            }
          });
        });
      }

      // Wait for the page to finish loading, then inject
      const tabListener = (tabId, info) => {
        if (tabId !== scrapeTabId || info.status !== "complete") return;
        injectScraper(tabId);
      };

      chrome.tabs.onUpdated.addListener(tabListener);

      // Listen for progress updates and final results from the scraper
      const progressListener = (message, msgSender) => {
        if (!msgSender.tab || msgSender.tab.id !== scrapeTabId) return;

        // ── Progress update ──
        if (message.action === "scrapeProgress") {
          console.log(`[TrustKaro] Progress: ${message.count} reviews`);

          // Forward progress to the origin tab (website bridge) if still open
          if (originTabId) {
            chrome.tabs.sendMessage(originTabId, {
              action: "scrapeProgress",
              count: message.count,
              message: message.message || `Scraped ${message.count} reviews…`
            }).catch(() => { });
          }
        }

        // ── Scrape complete ──
        if (message.action === "scrapeComplete") {
          // Cleanup listeners
          chrome.runtime.onMessage.removeListener(progressListener);
          chrome.tabs.onUpdated.removeListener(tabListener);

          const reviews = message.reviews || [];
          const productTitle = message.productTitle || "Product";
          const productImage = message.productImage || null;

          console.log(`[TrustKaro] Scrape done: ${reviews.length} reviews`);

          // Tell the overlay on the scrape tab to show "Analyzing" stage
          chrome.tabs.sendMessage(scrapeTabId, {
            action: "trustKaroAnalyzing",
            count: reviews.length
          }).catch(() => { });

          // Also notify origin tab
          if (originTabId) {
            chrome.tabs.sendMessage(originTabId, {
              action: "scrapeProgress",
              count: reviews.length,
              message: "Running AI analysis…"
            }).catch(() => { });
          }

          // Send reviews to backend API
          fetch(`${API_BASE}/api/analyze`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              platform,
              product_title: productTitle,
              product_image: productImage,
              product_link: url,
              reviews,
              source: "home"
            })
          })
            .then(r => r.json())
            .then(data => {
              if (data.error) {
                console.error("[TrustKaro] API error:", data.error);
                // Close scrape tab
                chrome.tabs.remove(scrapeTabId).catch(() => { });
                if (originTabId) {
                  chrome.tabs.sendMessage(originTabId, {
                    action: "scrapeError",
                    message: data.error
                  }).catch(() => { });
                }
                return;
              }

              // Append price session ID to result URL so the page can poll
              // immediately without waiting for extension ready signal
              const psidParam = priceSessionId ? `?psid=${priceSessionId}` : '';
              const resultUrl = `${API_BASE}/result/${data.job_id}${psidParam}`;
              console.log(`[TrustKaro] Redirecting origin tab to: ${resultUrl}`);

              // Close the scrape tab (product page)
              chrome.tabs.remove(scrapeTabId).catch(() => { });

              // Navigate the ORIGIN tab (Trust Karo page) to results
              if (originTabId) {
                chrome.tabs.update(originTabId, { url: resultUrl, active: true });
              } else {
                // Fallback: open new tab
                chrome.tabs.create({ url: resultUrl });
              }
            })
            .catch(err => {
              console.error("[TrustKaro] Fetch error:", err);
              // Close scrape tab
              chrome.tabs.remove(scrapeTabId).catch(() => { });
              if (originTabId) {
                chrome.tabs.sendMessage(originTabId, {
                  action: "scrapeError",
                  message: "Could not connect to Trust Karo server. Is it running?"
                }).catch(() => { });
              }
            });
        }
      };

      chrome.runtime.onMessage.addListener(progressListener);
    });

    sendResponse({ started: true });
    return true; // keep message channel open
  }

  // ---------- DETECT PLATFORM (from popup) ----------
  if (msg.action === "detectPlatform") {
    sendResponse({ platform: detectPlatform(msg.url) });
    return false;
  }

  // ---------- START PRICE COMPARISON (BuyHatke integration) ----------
  if (msg.action === "start_price_compare") {
    console.log('[TrustKaro-Price] Starting price compare for:', msg.url, 'session:', msg.session_id);
    priceOrchestrateAll(msg.url, msg.session_id);
    sendResponse({ status: 'started' });
    return true;
  }
});

// ============================================================
// PRICE COMPARISON ENGINE  (ported from BuyHatke background.js)
// All API calls go to TrustKaro backend on port 8010
// ============================================================

const PRICE_PLATFORMS = [
  { name: 'Amazon',   domain: 'amazon.in'    },
  { name: 'Flipkart', domain: 'flipkart.com' },
  { name: 'Myntra',   domain: 'myntra.com'   },
];

const priceActiveSessions = {};

// ── Platform relevance: skip platforms that don't sell this category ──
const MYNTRA_SKIP_KEYWORDS = [
  'phone','mobile','smartphone','iphone','galaxy','pixel','oneplus','redmi',
  'realme','vivo','oppo','motorola','nokia','poco','iqoo','nothing phone',
  'laptop','notebook','macbook','chromebook','tablet','ipad',
  'computer','desktop','monitor','tv','television','led tv','oled',
  'camera','dslr','gopro','webcam','projector',
  'headphone','earphone','earbud','airpod','speaker','soundbar','amplifier',
  'printer','scanner','router','modem','hard disk','hard drive','ssd','pen drive',
  'keyboard','mouse','gamepad','joystick','controller',
  'gpu','graphics card','processor','cpu','motherboard','ram',
  'refrigerator','fridge','washing machine','dishwasher','dryer',
  'air conditioner','microwave','oven','mixer','grinder','blender','juicer',
  'iron box','fan','cooler','heater','purifier','humidifier','geyser',
  'trimmer','shaver','epilator',
  'console','playstation','xbox','nintendo','switch',
  'smartwatch','fitness band','powerbank','power bank',
];

function priceIsPlatformRelevant(platformName, productTitle) {
  if (platformName !== 'Myntra') return true;
  const t = productTitle.toLowerCase();
  return !MYNTRA_SKIP_KEYWORDS.some(kw => t.includes(kw));
}

// ── Title relevance: reject accessories when user searched for a main product ──
const ACCESSORY_INDICATORS = [
  'cover','case','pouch','sleeve','skin','protector','guard','tempered glass',
  'screen protector','film','sticker','decal','wrap','folio',
  'bag','backpack','stand','holder','mount','dock','cradle','tripod',
  'strap','band','buckle','cable','adapter','dongle','hub',
  'cleaning kit','toolkit','tool kit','lens cap',
];

function priceIsTitleRelevant(originalTitle, foundTitle) {
  if (!originalTitle || !foundTitle) return true;
  const origLower  = originalTitle.toLowerCase();
  const foundLower = foundTitle.toLowerCase();

  // If found title has an accessory keyword the original doesn't, reject
  for (const kw of ACCESSORY_INDICATORS) {
    if (foundLower.includes(kw) && !origLower.includes(kw)) {
      console.log(`[TrustKaro-Price] Title mismatch: found "${kw}" in result but not in original`);
      return false;
    }
  }
  return true;
}

async function priceOrchestrateAll(sourceUrl, sessionId) {
  priceActiveSessions[sessionId] = { tabs: [] };
  const session = priceActiveSessions[sessionId];

  if (!sourceUrl.startsWith('http://') && !sourceUrl.startsWith('https://')) {
    sourceUrl = 'https://www.' + sourceUrl;
  }

  try {
    // STEP 1: Extract product title
    const srcTab = await chrome.tabs.create({ url: sourceUrl, active: false });
    session.tabs.push(srcTab.id);
    await priceWaitForLoad(srcTab.id);
    const titleRes = await chrome.scripting.executeScript({ target: { tabId: srcTab.id }, func: priceExtractTitle });
    priceSafeClose(srcTab.id);

    const productTitle = titleRes?.[0]?.result || '';
    if (!productTitle) { await priceSubmitFinal(sessionId, 'Unknown Product', []); priceCleanup(session); return; }

    const sourcePlatformName = priceDetectPlatformName(sourceUrl);
    const searchQuery = priceCleanTitle(productTitle);

    // STEP 2: Search all platforms in parallel
    const promises = PRICE_PLATFORMS.map(platform => {
      // Skip platforms that don't sell this product category
      if (!priceIsPlatformRelevant(platform.name, productTitle)) {
        console.log(`[TrustKaro-Price] Skipping ${platform.name} — product category not sold there`);
        return Promise.resolve({ store: platform.name, price: null, title: 'Category not available', url: '', found: false });
      }
      if (platform.name === sourcePlatformName) {
        return priceScrapePagePrice(sourceUrl, session).then(async ({price}) => {
          if (price !== null) return { store: platform.name, price, title: productTitle, url: sourceUrl, found: true };
          return priceSearchAndScrape(platform, searchQuery, productTitle, session);
        });
      }
      return priceSearchAndScrape(platform, searchQuery, productTitle, session);
    });

    const results = await Promise.all(promises);
    results.sort((a, b) => { if (a.found && !b.found) return -1; if (!a.found && b.found) return 1; return (a.price||0)-(b.price||0); });
    await priceSubmitFinal(sessionId, productTitle, results);
  } catch (err) {
    console.error('[TrustKaro-Price] Fatal error:', err);
    await priceSubmitFinal(sessionId, 'Error', []);
  }
  priceCleanup(session);
}

async function priceSearchAndScrape(platform, searchQuery, productTitle, session) {
  try {
    const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(searchQuery + ' site:' + platform.domain)}&hl=en&num=5`;
    const googleTab = await chrome.tabs.create({ url: googleUrl, active: false });
    session.tabs.push(googleTab.id);
    await priceWaitForLoad(googleTab.id);
    const linkRes = await chrome.scripting.executeScript({ target: { tabId: googleTab.id }, func: priceExtractFirstLink, args: [platform.domain] });
    priceSafeClose(googleTab.id);
    const productLink = linkRes?.[0]?.result;
    if (!productLink) return await priceTryGoogleShopping(platform, searchQuery, productTitle, session);
    const {price, pageTitle} = await priceScrapePagePrice(productLink, session);
    if (price !== null && priceIsTitleRelevant(productTitle, pageTitle)) {
      return { store: platform.name, price, title: productTitle, url: productLink, found: true };
    }
    if (price !== null) console.log(`[TrustKaro-Price] Rejected ${platform.name}: "${pageTitle}" doesn't match "${productTitle}"`);
    const shopResult = await priceTryGoogleShopping(platform, searchQuery, productTitle, session);
    if (shopResult.found) shopResult.url = productLink;
    return shopResult;
  } catch (err) {
    return { store: platform.name, price: null, title: 'Search failed', url: '', found: false };
  }
}

async function priceTryGoogleShopping(platform, searchQuery, productTitle, session) {
  try {
    const shopTab = await chrome.tabs.create({ url: `https://www.google.com/search?q=${encodeURIComponent(searchQuery)}&tbm=shop&hl=en`, active: false });
    session.tabs.push(shopTab.id);
    await priceWaitForLoad(shopTab.id);
    const res = await chrome.scripting.executeScript({ target: { tabId: shopTab.id }, func: priceGoogleShoppingForStore, args: [platform.name] });
    priceSafeClose(shopTab.id);
    const price = res?.[0]?.result;
    if (price && price > 0) return { store: platform.name, price, title: productTitle, url: '', found: true };
  } catch(err) {}
  return { store: platform.name, price: null, title: 'Product not found', url: '', found: false };
}

async function priceScrapePagePrice(url, session) {
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    session.tabs.push(tab.id);
    await priceWaitForLoad(tab.id);
    const [priceRes, titleRes] = await Promise.all([
      chrome.scripting.executeScript({ target: { tabId: tab.id }, func: priceExtractFromPage }),
      chrome.scripting.executeScript({ target: { tabId: tab.id }, func: priceExtractTitle }),
    ]);
    priceSafeClose(tab.id);
    return {
      price: priceRes?.[0]?.result || null,
      pageTitle: titleRes?.[0]?.result || '',
    };
  } catch(err) { return { price: null, pageTitle: '' }; }
}

// ── Injected functions ────────────────────────────────────────────────────────

function priceExtractTitle() {
  const host = window.location.hostname;
  if (host.includes('amazon')) { const el=document.querySelector('#productTitle')||document.querySelector('#title'); if (el) return el.innerText.trim(); }
  if (host.includes('flipkart')) { const el=document.querySelector('span.VU-ZEz')||document.querySelector('span.B_NuCI')||document.querySelector('h1._9E25nV'); if (el) return el.innerText.trim(); }
  if (host.includes('myntra')) { const b=document.querySelector('.pdp-title'),n=document.querySelector('.pdp-name'); if (b&&n) return b.innerText.trim()+' '+n.innerText.trim(); if (n) return n.innerText.trim(); }
  const og=document.querySelector('meta[property="og:title"]'); if (og) return og.getAttribute('content').trim();
  return document.title.replace(/ - Amazon.*$/,'').replace(/ \| Flipkart.*$/,'').replace(/ - Buy.*$/,'').trim();
}

function priceExtractFirstLink(domain) {
  for (const link of document.querySelectorAll('#search a[href], #rso a[href]')) {
    const href=link.href;
    if (!href.includes(domain)) continue;
    if (href.includes('google.com/')&&!href.includes('url?')) continue;
    if (href.includes('webcache.')||href.includes('translate.google')) continue;
    if (domain==='amazon.in'&&(href.includes('/dp/')||href.includes('/gp/'))) return href;
    if (domain==='flipkart.com'&&href.includes('/p/')) return href;
    if (domain==='myntra.com'&&(/\/\d+\/buy/.test(href)||/\/\d+$/.test(href))) return href;
  }
  return null;
}

function priceGoogleShoppingForStore(storeName) {
  const aliases={Amazon:['amazon','amazon.in'],Flipkart:['flipkart','flipkart.com'],Myntra:['myntra','myntra.com']};
  const list=aliases[storeName]||[storeName.toLowerCase()];
  for (const el of document.querySelectorAll('*')) {
    if (el.children.length>5) continue;
    const text=(el.innerText||'').trim();
    if (text.length>500||text.length<5) continue;
    if (!list.some(a=>text.toLowerCase().includes(a))) continue;
    const m=text.match(/\u20b9\s?([0-9,]+)/); if (m){const p=parseInt(m[1].replace(/,/g,''),10);if(p>0)return p;}
  }
  for (const alias of list) {
    for (const link of document.querySelectorAll(`a[href*="${alias}"]`)) {
      let parent=link.parentElement;
      for (let i=0;i<8;i++){if(!parent)break;const m=(parent.innerText||'').match(/\u20b9\s?([0-9,]+)/);if(m){const p=parseInt(m[1].replace(/,/g,''),10);if(p>0)return p;}parent=parent.parentElement;}
    }
  }
  return null;
}

function priceExtractFromPage() {
  const host=window.location.hostname;
  function parsePrice(t){if(!t)return null;const n=parseInt(t.replace(/\.\d{1,2}/,'').replace(/[^0-9]/g,''),10);return(isNaN(n)||n<=0)?null:n;}
  if (host.includes('amazon')) {
    const avail=document.querySelector('#availability,#outOfStock');
    if(avail&&(avail.innerText.toLowerCase().includes('currently unavailable')||avail.innerText.toLowerCase().includes('out of stock')))return null;
    for(const s of document.querySelectorAll('script[type="application/ld+json"]')){try{const d=JSON.parse(s.textContent);for(const item of(Array.isArray(d)?d:[d])){if(item['@type']==='Product'&&item.offers){for(const o of(Array.isArray(item.offers)?item.offers:[item.offers])){if(o.availability&&o.availability.includes('OutOfStock'))continue;const p=parseInt(o.price||o.lowPrice||'0',10);if(p>0)return p;}}}}catch(e){}}
    for(const sel of['#corePriceDisplay_desktop_feature_div .a-price .a-offscreen','.priceToPay .a-offscreen','#corePrice_desktop .a-price .a-offscreen','#priceblock_ourprice','#priceblock_dealprice','.a-price .a-offscreen','.reinventPricePriceToPayMargin .a-offscreen']){const el=document.querySelector(sel);if(el){const p=parsePrice((el.innerText||el.textContent||'').trim());if(p)return p;}}
    const col=document.querySelector('#rightCol,#desktop_buybox,#buybox,#centerCol');if(col){const m=col.innerText.match(/\u20b9\s?([0-9,]+)/);if(m){const p=parseInt(m[1].replace(/,/g,''),10);if(p>0)return p;}}
  }
  if (host.includes('flipkart')) {
    if((document.body.innerText||'').includes('Sold Out'))return null;
    for(const s of document.querySelectorAll('script[type="application/ld+json"]')){try{const d=JSON.parse(s.textContent);for(const item of(Array.isArray(d)?d:[d])){if(item['@type']==='Product'&&item.offers){for(const o of(Array.isArray(item.offers)?item.offers:[item.offers])){const p=parseInt(o.price||o.lowPrice||'0',10);if(p>0)return p;}}}}catch(e){}}
    const meta=document.querySelector('meta[property="product:price:amount"],meta[property="og:price:amount"]');if(meta){const p=parseInt(meta.getAttribute('content'),10);if(p>0)return p;}
    for(const btn of document.querySelectorAll('button')){const m=(btn.innerText||'').match(/(?:Buy\s*(?:at|now)?|\u20b9)\s*\u20b9?\s*([0-9,]+)/i);if(m&&(btn.innerText||'').toLowerCase().includes('buy')){const p=parseInt(m[1].replace(/,/g,''),10);if(p>0)return p;}}
  }
  if (host.includes('myntra')) {
    const path=window.location.pathname;if(path==='/'||!(/\/\d+/.test(path)))return null;
    if(!document.querySelector('.pdp-name,.pdp-title'))return null;
    for(const s of document.querySelectorAll('script[type="application/ld+json"]')){try{const d=JSON.parse(s.textContent);for(const item of(Array.isArray(d)?d:[d])){if(item['@type']==='Product'&&item.offers){for(const o of(Array.isArray(item.offers)?item.offers:[item.offers])){const p=parseInt(o.price||o.lowPrice||'0',10);if(p>0)return p;}}}}catch(e){}}
    for(const sel of['.pdp-price strong','.pdp-discount-container .pdp-price','.pdp-mrp .pdp-price']){const el=document.querySelector(sel);if(el){const p=parsePrice(el.innerText.trim());if(p)return p;}}
  }
  return null;
}

// ── Utilities ───────────────────────────────────────────────────────────────

function priceDetectPlatformName(url) {
  if (url.includes('amazon'))   return 'Amazon';
  if (url.includes('flipkart')) return 'Flipkart';
  if (url.includes('myntra'))   return 'Myntra';
  return 'Unknown';
}

function priceWaitForLoad(tabId) {
  return new Promise(resolve => {
    const timeout = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 12000);
    function listener(id, info) { if (id===tabId && info.status==='complete') { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(listener); setTimeout(resolve, 2500); } }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function priceSafeClose(tabId) { try { chrome.tabs.remove(tabId); } catch(e) {} }

function priceCleanup(session) { setTimeout(() => { for (const id of session.tabs) priceSafeClose(id); }, 3000); }

function priceCleanTitle(title) {
  return title.replace(/\(.*?\)/g,'').replace(/\[.*?\]/g,'').replace(/[|\u2013\u2014:]/g,' ')
    .replace(/\b(with|for|and|the|in|on|of|by|from|pack|set|buy|online|india|price|rs|inr)\b/gi,'')
    .replace(/\s+/g,' ').trim().split(' ').slice(0,8).join(' ');
}

async function priceSubmitFinal(sessionId, productTitle, results) {
  try {
    await fetch(`${API_BASE}/api/price/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId, product_title: productTitle, results })
    });
    console.log('[TrustKaro-Price] Results submitted');
  } catch (err) {
    console.error('[TrustKaro-Price] Submit failed:', err);
  }
}
