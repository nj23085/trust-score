// ============================================
// TRUST KARO — SCRAPE PROGRESS OVERLAY
// Injected on product pages during scraping.
// Provides a full-screen overlay with live progress.
// ============================================

(function () {
  "use strict";

  // Don't re-create if already exists
  if (window.__tkOverlay) return;

  // ── Inject Styles ──────────────────────────────────────────
  const style = document.createElement("style");
  style.id = "trustkaro-overlay-css";
  style.textContent = `
    #tk-scrape-overlay {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      z-index: 2147483647;
      background: rgba(10, 10, 30, 0.82);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      animation: tkFadeIn 0.35s ease;
    }
    @keyframes tkFadeIn { from{opacity:0} to{opacity:1} }
    @keyframes tkSpin  { to{transform:rotate(360deg)} }
    @keyframes tkShimmer {
      0%{background-position:-200% 0}
      100%{background-position:200% 0}
    }

    .tk-card {
      background: linear-gradient(145deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 22px;
      padding: 44px 52px;
      max-width: 480px;
      width: 90%;
      text-align: center;
      color: #fff;
      box-shadow: 0 30px 60px rgba(0,0,0,0.55);
    }

    .tk-brand {
      font-size: 42px;
      font-weight: 800;
      margin-bottom: 4px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    .tk-tagline {
      font-size: 12px;
      color: rgba(255,255,255,0.4);
      margin-bottom: 32px;
      letter-spacing: 1px;
    }

    .tk-spinner {
      width: 44px; height: 44px;
      border: 3px solid rgba(255,255,255,0.08);
      border-top-color: #667eea;
      border-radius: 50%;
      animation: tkSpin 0.75s linear infinite;
      margin: 0 auto 22px;
    }

    .tk-message {
      font-size: 15px;
      font-weight: 500;
      color: rgba(255,255,255,0.88);
      margin-bottom: 22px;
      min-height: 22px;
    }

    .tk-progress-track {
      width: 100%; height: 7px;
      background: rgba(255,255,255,0.08);
      border-radius: 4px;
      overflow: hidden;
      margin-bottom: 10px;
    }
    .tk-progress-bar {
      height: 100%;
      background: linear-gradient(90deg, #667eea, #764ba2, #667eea);
      background-size: 200% 100%;
      border-radius: 4px;
      transition: width 0.45s ease;
      width: 3%;
      animation: tkShimmer 2s linear infinite;
    }

    .tk-stats {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: rgba(255,255,255,0.5);
      margin-bottom: 26px;
    }
    .tk-count { color: #667eea; font-weight: 600; }

    .tk-stages {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    .tk-stg {
      display: flex; align-items: center; gap: 5px;
      font-size: 11px;
      color: rgba(255,255,255,0.3);
      transition: all 0.3s ease;
    }
    .tk-stg.active { color: #667eea; }
    .tk-stg.active .tk-dot {
      background: #667eea;
      box-shadow: 0 0 8px rgba(102,126,234,0.5);
    }
    .tk-stg.complete { color: #34d399; }
    .tk-stg.complete .tk-dot { background: #34d399; }
    .tk-dot {
      width: 8px; height: 8px;
      border-radius: 50%;
      background: rgba(255,255,255,0.18);
      transition: all 0.3s ease;
    }
    .tk-line {
      width: 20px; height: 2px;
      background: rgba(255,255,255,0.12);
    }

    .tk-error-msg {
      color: #f87171;
      font-size: 14px;
      margin-top: 14px;
    }
    .tk-home-btn {
      margin-top: 18px;
      padding: 10px 28px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border: none; border-radius: 10px;
      color: #fff; font-size: 14px; font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
    }
    .tk-home-btn:hover { opacity: 0.9; }
  `;
  document.documentElement.appendChild(style);

  // ── Create Overlay DOM ─────────────────────────────────────
  const overlay = document.createElement("div");
  overlay.id = "tk-scrape-overlay";
  overlay.innerHTML = `
    <div class="tk-card">
      <div class="tk-brand">TrustKaro</div>
      <div class="tk-tagline">CHECK KARO PHIR BUY KARO</div>
      <div class="tk-spinner" id="tkSpinner"></div>
      <div class="tk-message" id="tkMsg">Initializing scraper…</div>
      <div class="tk-progress-track">
        <div class="tk-progress-bar" id="tkBar"></div>
      </div>
      <div class="tk-stats">
        <span id="tkPct">3%</span>
        <span><span class="tk-count" id="tkCount">0</span> reviews scraped</span>
      </div>
      <div class="tk-stages">
        <div class="tk-stg active" id="tkStgScrape"><div class="tk-dot"></div>Scraping</div>
        <div class="tk-line"></div>
        <div class="tk-stg" id="tkStgAI"><div class="tk-dot"></div>AI Analysis</div>
        <div class="tk-line"></div>
        <div class="tk-stg" id="tkStgDone"><div class="tk-dot"></div>Done</div>
      </div>
    </div>
  `;
  document.documentElement.appendChild(overlay);

  // ── Refs ────────────────────────────────────────────────────
  const elMsg = document.getElementById("tkMsg");
  const elBar = document.getElementById("tkBar");
  const elPct = document.getElementById("tkPct");
  const elCount = document.getElementById("tkCount");
  const elStgScrape = document.getElementById("tkStgScrape");
  const elStgAI = document.getElementById("tkStgAI");
  const elStgDone = document.getElementById("tkStgDone");
  const elSpinner = document.getElementById("tkSpinner");
  const elCard = overlay.querySelector(".tk-card");

  // ── API ─────────────────────────────────────────────────────
  function update(count, message) {
    const pct = Math.min(5 + Math.floor((count / 100) * 65), 75);
    if (elMsg) elMsg.textContent = message || `Scraped ${count} reviews…`;
    if (elBar) elBar.style.width = pct + "%";
    if (elPct) elPct.textContent = pct + "%";
    if (elCount) elCount.textContent = count;
  }

  function setStage(stage) {
    [elStgScrape, elStgAI, elStgDone].forEach(s => {
      if (s) { s.classList.remove("active", "complete"); }
    });

    if (stage === "scraping") {
      elStgScrape?.classList.add("active");
    } else if (stage === "analyzing") {
      elStgScrape?.classList.add("complete");
      elStgAI?.classList.add("active");
      if (elBar) elBar.style.width = "82%";
      if (elPct) elPct.textContent = "82%";
      if (elMsg) elMsg.textContent = "Running AI analysis…";
    } else if (stage === "done") {
      elStgScrape?.classList.add("complete");
      elStgAI?.classList.add("complete");
      elStgDone?.classList.add("active");
      if (elBar) elBar.style.width = "100%";
      if (elPct) elPct.textContent = "100%";
      if (elMsg) elMsg.textContent = "Redirecting to results…";
      if (elSpinner) elSpinner.style.borderTopColor = "#34d399";
    }
  }

  function showError(message) {
    if (elSpinner) elSpinner.style.display = "none";
    if (elMsg) elMsg.textContent = "Scraping Failed";
    if (elBar) elBar.style.background = "#f87171";

    const errDiv = document.createElement("div");
    errDiv.innerHTML = `
      <div class="tk-error-msg">${message}</div>
      <a class="tk-home-btn" href="http://127.0.0.1:8010/">← Go Home</a>
    `;
    elCard?.appendChild(errDiv);
  }

  // Expose globally for scraper scripts
  window.__tkOverlay = { update, setStage, showError };

  // ── Listen for messages from background.js ──────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "trustKaroAnalyzing") {
      setStage("analyzing");
      update(msg.count || 0, "Running AI analysis…");
    }
    if (msg.action === "trustKaroDone") {
      setStage("done");
    }
    if (msg.action === "trustKaroError") {
      showError(msg.message || "An unknown error occurred.");
    }
  });

})();
